# Entregable de Inteligencia Artificial - Evaluación 1

**Herramienta utilizada:** Google Gemini

### Prompt 1: Generación de Datos JSON
**Prompt exacto ingresado:**
"Actúa como un generador de datos. Crea un archivo JSON en el formato 'fixture' de Django para pre-cargar datos de prueba en una base de datos. Los modelos son 'academic.teacher' (first_name, last_name), 'academic.course' (name, teacher), 'academic.student' (first_name, last_name) y 'academic.studentcourse' (student, course). Genera 2 profesores, 2 cursos, 2 estudiantes y 2 inscripciones."

**Respuesta de la IA (Fragmento):**
```json
[
  {"model": "academic.teacher", "pk": 1, "fields": {"first_name": "Marcelo", "last_name": "Alvarado"}}
  // ... (Estructura JSON generada correctamente)
]