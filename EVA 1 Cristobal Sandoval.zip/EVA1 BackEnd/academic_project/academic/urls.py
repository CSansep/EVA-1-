from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Configuración del Router para la API
router = DefaultRouter()
router.register(r'teachers', views.TeacherViewSet)
router.register(r'courses', views.CourseViewSet)
router.register(r'students', views.StudentViewSet)

urlpatterns = [
    # Rutas API
    path('api/', include(router.urls)),
    
    # Rutas HTML
    path('', views.home_view, name='home'),
    path('courses/', views.courses_view, name='courses'),
    path('students/', views.students_view, name='students'),
]