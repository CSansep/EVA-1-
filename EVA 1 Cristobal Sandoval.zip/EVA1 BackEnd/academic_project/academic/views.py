from django.shortcuts import render
from rest_framework import viewsets
from .models import Teacher, Course, Student
from .serializers import TeacherSerializer, CourseSerializer, StudentSerializer

# --- 1. ENDPOINTS DE LA API (DRF) ---
class TeacherViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Teacher.objects.all()
    serializer_class = TeacherSerializer

class CourseViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

class StudentViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer


# --- 2. VISTAS HTML (Enmascaramiento) ---
def home_view(request):
    """Vista para la ruta raíz, elimina el error 404"""
    return render(request, 'academic/base.html')

def courses_view(request):
    """Vista para el listado de cursos"""
    return render(request, 'academic/courses.html')

def students_view(request):
    """Vista para el listado de estudiantes"""
    return render(request, 'academic/students.html')